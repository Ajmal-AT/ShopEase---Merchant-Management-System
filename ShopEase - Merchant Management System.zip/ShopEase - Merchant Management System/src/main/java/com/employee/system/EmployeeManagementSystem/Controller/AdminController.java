package com.employee.system.EmployeeManagementSystem.Controller;

import com.employee.system.EmployeeManagementSystem.Entity.Admin;
import com.employee.system.EmployeeManagementSystem.Model.AdminModel;
import com.employee.system.EmployeeManagementSystem.Repository.AdminRepository;
import com.employee.system.EmployeeManagementSystem.Service.MyUserDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/admins")
public class AdminController {

    @Autowired
    private MyUserDetailsService adminService;

    @Autowired
    private AdminRepository adminRepository;

    @PostMapping(value = "/register")
    public Admin registerAdmin(@RequestBody AdminModel adminModel) {
        return adminService.registerAdmin(adminModel);
    }

    @PostMapping("/login")
    public ResponseEntity<?> loginAdmin(@RequestBody AdminModel adminModel) {
        String token = adminService.authenticateAdmin(adminModel);
        if (token != null) {
            return ResponseEntity.ok(token);
        } else {
            return ResponseEntity.status(401).body("Invalid credentials");
        }
    }

}
