package com.employee.system.EmployeeManagementSystem.Controller;

import com.employee.system.EmployeeManagementSystem.Entity.Category;
import com.employee.system.EmployeeManagementSystem.Model.CategoryModel;
import com.employee.system.EmployeeManagementSystem.Service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/categories")
public class CategoryController {

    @Autowired
    private CategoryService categoryService;

    @PostMapping(value = "/create")
    public ResponseEntity<Category> addCategory(@RequestBody CategoryModel categoryModel) {
        return ResponseEntity.ok(categoryService.addCategory(categoryModel));
    }

    @GetMapping
    public ResponseEntity<List<Category>> getAllCategories() {
        return ResponseEntity.ok(categoryService.getAllCategories());
    }

}