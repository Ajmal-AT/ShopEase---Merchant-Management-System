package com.employee.system.EmployeeManagementSystem.Controller;

import com.employee.system.EmployeeManagementSystem.Entity.Category;
import com.employee.system.EmployeeManagementSystem.Entity.Merchant;
import com.employee.system.EmployeeManagementSystem.Model.MerchantModel;
import com.employee.system.EmployeeManagementSystem.Service.CategoryService;
import com.employee.system.EmployeeManagementSystem.Service.MerchantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/merchants")
public class MerchantController {

    @Autowired
    MerchantService merchantService;

    @Autowired
    CategoryService categoryService;

    @PostMapping(value = "/create")
    public ResponseEntity<Merchant> addMerchant(@RequestBody MerchantModel merchantModel, @RequestParam Long categoryId) {
        Category category = categoryService.getCategoryById(categoryId);
        if (category == null) {
            return ResponseEntity.badRequest().build();
        }
        Merchant merchant = merchantService.addMerchant(merchantModel, category);
        return new ResponseEntity<>(merchant, HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<List<Merchant>> getAllMerchants() {
        return ResponseEntity.ok(merchantService.getAllMerchants());
    }

    @GetMapping(value = "/{id}")
    public ResponseEntity<Merchant> getMerchantById(@PathVariable Long id) {
        Merchant merchant = merchantService.getMerchantById(id);
        if (merchant == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(merchant);
    }

    @DeleteMapping(value = "/{id}")
    public ResponseEntity<Void> deleteMerchant(@PathVariable Long id) {
        merchantService.deleteMerchant(id);
        return ResponseEntity.noContent().build();
    }

}
