package com.employee.system.EmployeeManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MerchantManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(MerchantManagementSystemApplication.class, args);
	}

}
