package com.employee.system.EmployeeManagementSystem.Model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class AdminModel {

    @JsonProperty("user_name")
    private String username;

    @JsonProperty("password")
    private String password;

}
