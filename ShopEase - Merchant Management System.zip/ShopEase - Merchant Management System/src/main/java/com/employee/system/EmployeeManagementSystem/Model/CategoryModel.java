package com.employee.system.EmployeeManagementSystem.Model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class CategoryModel {

    @JsonProperty("category_name")
    private String name;

    @JsonProperty("category_description")
    private String description;

}
