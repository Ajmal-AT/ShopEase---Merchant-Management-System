package com.employee.system.EmployeeManagementSystem.Model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class MerchantModel {

    @NotNull
    @JsonProperty("shop_name")
    private String shopName;

    @NotNull
    @JsonProperty("phone_number")
    private String phoneNumber;

    @NotNull
    @JsonProperty("owner_name")
    private String ownerName;

    @JsonProperty("email")
    private String email;

    @NotNull
    @JsonProperty("address")
    private String address;

    @JsonProperty("city")
    private String city;

    @JsonProperty("state")
    private String state;

    @NotNull
    @JsonProperty("zip_code")
    private String zipCode;

}
