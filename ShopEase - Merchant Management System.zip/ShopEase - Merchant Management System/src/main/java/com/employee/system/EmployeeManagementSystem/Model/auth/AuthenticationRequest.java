package com.employee.system.EmployeeManagementSystem.Model.auth;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class AuthenticationRequest {
    @JsonProperty("user_name")
    private String username;

    @JsonProperty("password")
    private String password;
}
