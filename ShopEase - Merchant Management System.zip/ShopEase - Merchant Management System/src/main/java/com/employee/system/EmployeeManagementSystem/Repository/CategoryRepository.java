package com.employee.system.EmployeeManagementSystem.Repository;

import com.employee.system.EmployeeManagementSystem.Entity.Category;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CategoryRepository extends JpaRepository<Category, Long> {
    Category findByName(String role);

    boolean existsByName(String departmentName);

    List<Category> findAllCategoryByIsActiveTrue();

}
