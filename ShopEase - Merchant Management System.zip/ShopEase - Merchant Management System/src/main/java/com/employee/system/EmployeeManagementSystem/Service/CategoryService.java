package com.employee.system.EmployeeManagementSystem.Service;

import com.employee.system.EmployeeManagementSystem.Entity.Category;
import com.employee.system.EmployeeManagementSystem.Model.CategoryModel;
import com.employee.system.EmployeeManagementSystem.Repository.CategoryRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoryService {
    @Autowired
    private CategoryRepository categoryRepository;

    ModelMapper modelMapper;
    public Category addCategory(CategoryModel categoryModel) {
        Category category = new Category();
        category.setName(categoryModel.getName());
        category.setDescription(categoryModel.getDescription());
        category.setActive(true);
        return categoryRepository.save(category);
    }

    public List<Category> getAllCategories() {
        return categoryRepository.findAll();
    }

    public List<Category> getAllActiveCategories() {
        return categoryRepository.findAllCategoryByIsActiveTrue();
    }

    public Category getCategoryById(Long categoryId) {
        return categoryRepository.findById(categoryId).get();
    }
}
