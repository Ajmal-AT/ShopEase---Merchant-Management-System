package com.employee.system.EmployeeManagementSystem.Service;

import com.employee.system.EmployeeManagementSystem.Entity.Category;
import com.employee.system.EmployeeManagementSystem.Entity.Merchant;
import com.employee.system.EmployeeManagementSystem.Model.MerchantModel;
import com.employee.system.EmployeeManagementSystem.Repository.MerchantRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class MerchantService {

    @Autowired
    private MerchantRepository merchantRepository;

    ModelMapper modelMapper;

    public Merchant addMerchant(MerchantModel merchantModel, Category category) {
        Merchant merchant = new Merchant();

        String username = getCurrentUsername();
        merchant.setShopName(merchantModel.getShopName());
        merchant.setPhoneNumber(merchantModel.getPhoneNumber());
        merchant.setOwnerName(merchantModel.getOwnerName());
        merchant.setRegistrationNumber(generateUniqueRegistrationNumber());
        merchant.setEmail(merchantModel.getEmail());
        merchant.setAddress(merchantModel.getAddress());
        merchant.setCity(merchantModel.getCity());
        merchant.setState(merchantModel.getState());
        merchant.setZipCode(merchantModel.getZipCode());
        merchant.setCreatedBy(username);
        merchant.setCategory(category);
        return merchantRepository.save(merchant);
    }

    public List<Merchant> getAllMerchants() {
        return merchantRepository.findAll();
    }

    public Merchant getMerchantById(Long id) {
        return merchantRepository.findById(id).orElse(null);
    }

    public void deleteMerchant(Long id) {
        merchantRepository.deleteById(id);
    }

    private String generateUniqueRegistrationNumber() {
        String registrationNumber;
        do {
            registrationNumber = "RN" + UUID.randomUUID().toString().replaceAll("-", "").substring(0, 6).toUpperCase();
        } while (merchantRepository.findByRegistrationNumber(registrationNumber) != null);
        return registrationNumber;
    }

    private String getCurrentUsername() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (principal instanceof UserDetails) {
            return ((UserDetails) principal).getUsername();
        } else {
            return principal.toString();
        }
    }

}
