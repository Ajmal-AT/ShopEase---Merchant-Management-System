package com.employee.system.EmployeeManagementSystem.Service;

import com.employee.system.EmployeeManagementSystem.Entity.Admin;
import com.employee.system.EmployeeManagementSystem.Model.AdminModel;
import com.employee.system.EmployeeManagementSystem.Repository.AdminRepository;
import com.employee.system.EmployeeManagementSystem.Security.SecurityConfigurer;
import org.modelmapper.ModelMapper;
import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.Date;

@Service
public class MyUserDetailsService implements UserDetailsService {

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    SecurityConfigurer securityConfigurer;

    @Autowired
    ModelMapper modelMapper;

    @Autowired
    PasswordEncoder passwordEncoder;

    private String secretKey = "shopEase";

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Admin admin = adminRepository.findByUsername(username);
        if (admin == null) {
            throw new UsernameNotFoundException("User not found with username: " + username);
        }

        return new User(admin.getUsername(), admin.getPassword(), new ArrayList<>());
    }

    public Admin registerAdmin(AdminModel adminModel) {
        Admin existAdmin = adminRepository.findByUsername(adminModel.getUsername());
        if (existAdmin != null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Username already exists, please login");
        }
        Admin admin = new Admin();
        admin.setUsername(adminModel.getUsername());
        admin.setPassword(adminModel.getPassword(), passwordEncoder);
        return adminRepository.save(admin);
    }

    public String authenticateAdmin(AdminModel adminModel) {
        Admin admin = adminRepository.findByUsername(adminModel.getUsername());
        if (admin != null) {
            if (passwordEncoder.matches(adminModel.getPassword(), admin.getPassword())) {
                return generateToken(admin.getUsername());
            }
        }
        return null;
    }

    private String generateToken(String username) {
        long expirationTime = 18000000; //5hour
        Date expirationDate = new Date(System.currentTimeMillis() + expirationTime);

        return JWT.create()
                .withSubject(username)
                .withExpiresAt(expirationDate)
                .withClaim("role", "admin")
                .sign(Algorithm.HMAC256(secretKey.getBytes()));
    }

}
